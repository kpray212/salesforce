SDOCS attachment tracker

This trigger and test class works on a master object and it's related attachments. Whenever an attacment is made on a particular record, the SFID of the attachment will append to the field "Attachment IDs" on the master record.

S-Docs is a Salesforce App which allows you to create multiple types of documents (PDF, HTML, Excel, etc.) - and allows you to attach documents to your created item as it is emailed.

However - the requirement here was to create an emailable document that attached several (but not all) of the documents attached to the original record. SDOCS makes used of the "&aid" parameter to do this automatically, but of course, you (or for a fee, SDOCS) will write the code for you.

I've written the code and test class for those folks that use SDOCS (it **is** a great program) but don't have the time (or heavy-duty expertise) or cash to do it themselves.

Please feel free to use and modify the code as your needs dictate. 